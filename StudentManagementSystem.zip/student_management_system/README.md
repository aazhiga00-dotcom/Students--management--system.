# Student Management System

A complete CRUD-based Student Management System built with:

- Frontend: HTML, CSS, JavaScript
- Backend: Django + Django REST Framework
- Database: SQLite
- API testing: Postman

## Features

- Create student
- Read/list students
- Read a single student
- Update student
- Delete student
- Search students
- Filter by department
- Client-side validation
- Server-side validation
- Duplicate email protection
- API error handling
- Responsive UI
- Django Admin
- Postman collection included

## Project structure

```text
student_management_system/
├── manage.py
├── requirements.txt
├── README.md
├── postman/
│   └── StudentManagement.postman_collection.json
├── student_management/
│   ├── __init__.py
│   ├── settings.py
│   ├── urls.py
│   ├── asgi.py
│   └── wsgi.py
└── students/
    ├── __init__.py
    ├── admin.py
    ├── apps.py
    ├── models.py
    ├── serializers.py
    ├── urls.py
    ├── views.py
    ├── migrations/
    │   └── __init__.py
    ├── templates/
    │   └── students/
    │       └── index.html
    └── static/
        └── students/
            ├── style.css
            └── app.js
```

## 1. Install Python

Use Python 3.10+.

Check:

```bash
python --version
```

On Windows, this may also work:

```bash
py --version
```

## 2. Open the project in VS Code

Open the folder containing `manage.py`.

## 3. Create a virtual environment

Windows:

```bash
python -m venv venv
```

Activate it:

```bash
venv\Scripts\activate
```

If PowerShell blocks activation, you can use:

```bash
venv\Scripts\activate.bat
```

## 4. Install packages

```bash
pip install -r requirements.txt
```

## 5. Create the database

```bash
python manage.py makemigrations
python manage.py migrate
```

## 6. Optional: create an admin user

```bash
python manage.py createsuperuser
```

Follow the prompts.

## 7. Start the server

```bash
python manage.py runserver
```

Open:

```text
http://127.0.0.1:8000/
```

The Student Management website will open.

Admin:

```text
http://127.0.0.1:8000/admin/
```

## API endpoints

Base URL:

```text
http://127.0.0.1:8000/api/students/
```

| Operation | Method | URL |
|---|---|---|
| Create | POST | `/api/students/` |
| Read all | GET | `/api/students/` |
| Read one | GET | `/api/students/{id}/` |
| Update | PUT | `/api/students/{id}/` |
| Partial update | PATCH | `/api/students/{id}/` |
| Delete | DELETE | `/api/students/{id}/` |

## Postman

Import:

```text
postman/StudentManagement.postman_collection.json
```

The collection contains:

1. Get all students
2. Create student
3. Get one student
4. Update student
5. Partial update
6. Delete student
7. Validation test
8. Invalid ID test

The collection uses the variable:

```text
{{base_url}}
```

with default value:

```text
http://127.0.0.1:8000
```

## Example POST body

```json
{
  "name": "Arun Kumar",
  "email": "arun@example.com",
  "phone": "9876543210",
  "department": "Computer Science",
  "year": 3,
  "cgpa": 8.5
}
```

## Notes

The SQLite database file is created after running migrations. It is intentionally not included in the source archive.

For production deployment, move secrets/configuration to environment variables and use a production database/server.
