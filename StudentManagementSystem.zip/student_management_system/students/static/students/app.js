const API_URL = "/api/students/";

const form = document.getElementById("studentForm");
const tableBody = document.getElementById("studentTableBody");
const messageBox = document.getElementById("message");
const formTitle = document.getElementById("formTitle");
const submitBtn = document.getElementById("submitBtn");
const cancelBtn = document.getElementById("cancelBtn");
const refreshBtn = document.getElementById("refreshBtn");
const searchInput = document.getElementById("searchInput");
const departmentFilter = document.getElementById("departmentFilter");

let editingId = null;
let searchTimer = null;

document.addEventListener("DOMContentLoaded", loadStudents);
form.addEventListener("submit", handleSubmit);
cancelBtn.addEventListener("click", resetForm);
refreshBtn.addEventListener("click", loadStudents);
searchInput.addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(loadStudents, 250);
});
departmentFilter.addEventListener("change", loadStudents);

async function loadStudents() {
    const params = new URLSearchParams();
    const search = searchInput.value.trim();
    const department = departmentFilter.value;

    if (search) params.set("search", search);
    if (department) params.set("department", department);

    try {
        setApiStatus("API connected");
        const response = await fetch(`${API_URL}?${params.toString()}`);

        if (!response.ok) {
            throw new Error("Could not load students.");
        }

        const students = await response.json();
        renderStudents(students);
        updateStats(students);
    } catch (error) {
        setApiStatus("API unavailable");
        tableBody.innerHTML = `
            <tr><td colspan="8" class="empty">
                Could not connect to the backend. Start Django with
                <code>python manage.py runserver</code>.
            </td></tr>`;
        showMessage(error.message, "error-message");
    }
}

function renderStudents(students) {
    if (!students.length) {
        tableBody.innerHTML = `
            <tr><td colspan="8" class="empty">No students found.</td></tr>`;
        return;
    }

    tableBody.innerHTML = students.map(student => `
        <tr>
            <td>${escapeHtml(student.id)}</td>
            <td>${escapeHtml(student.name)}</td>
            <td>${escapeHtml(student.email)}</td>
            <td>${escapeHtml(student.phone)}</td>
            <td>${escapeHtml(student.department)}</td>
            <td>${escapeHtml(yearLabel(student.year))}</td>
            <td>${escapeHtml(Number(student.cgpa).toFixed(2))}</td>
            <td>
                <div class="actions">
                    <button class="edit-btn" type="button" onclick="editStudent(${student.id})">Edit</button>
                    <button class="danger-btn" type="button" onclick="deleteStudent(${student.id})">Delete</button>
                </div>
            </td>
        </tr>
    `).join("");
}

function updateStats(students) {
    document.getElementById("totalStudents").textContent = students.length;

    const departments = new Set(students.map(s => s.department));
    document.getElementById("totalDepartments").textContent = departments.size;

    const average = students.length
        ? students.reduce((sum, s) => sum + Number(s.cgpa), 0) / students.length
        : 0;

    document.getElementById("averageCgpa").textContent = average.toFixed(2);
}

async function handleSubmit(event) {
    event.preventDefault();
    clearErrors();

    const data = {
        name: document.getElementById("name").value.trim(),
        email: document.getElementById("email").value.trim(),
        phone: document.getElementById("phone").value.trim(),
        department: document.getElementById("department").value,
        year: Number(document.getElementById("year").value),
        cgpa: Number(document.getElementById("cgpa").value)
    };

    if (!validateClient(data)) return;

    const method = editingId ? "PUT" : "POST";
    const url = editingId ? `${API_URL}${editingId}/` : API_URL;

    try {
        const response = await fetch(url, {
            method,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json().catch(() => ({}));

        if (!response.ok) {
            showServerErrors(result);
            return;
        }

        showMessage(editingId ? "Student updated successfully." : "Student added successfully.", "success");
        resetForm();
        await loadStudents();
    } catch (error) {
        showMessage("Backend server is not available.", "error-message");
    }
}

function validateClient(data) {
    let valid = true;

    if (!data.name || data.name.length < 2) {
        setError("name", "Enter a name with at least 2 characters.");
        valid = false;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
        setError("email", "Enter a valid email address.");
        valid = false;
    }

    if (!/^\d{10}$/.test(data.phone)) {
        setError("phone", "Phone number must contain exactly 10 digits.");
        valid = false;
    }

    if (!data.department) {
        setError("department", "Select a department.");
        valid = false;
    }

    if (![1, 2, 3, 4].includes(data.year)) {
        setError("year", "Select a valid year.");
        valid = false;
    }

    if (!Number.isFinite(data.cgpa) || data.cgpa < 0 || data.cgpa > 10) {
        setError("cgpa", "CGPA must be between 0 and 10.");
        valid = false;
    }

    return valid;
}

async function editStudent(id) {
    try {
        const response = await fetch(`${API_URL}${id}/`);
        if (!response.ok) throw new Error("Student not found.");

        const student = await response.json();

        editingId = id;
        document.getElementById("name").value = student.name;
        document.getElementById("email").value = student.email;
        document.getElementById("phone").value = student.phone;
        document.getElementById("department").value = student.department;
        document.getElementById("year").value = student.year;
        document.getElementById("cgpa").value = student.cgpa;

        formTitle.textContent = `Edit Student #${id}`;
        submitBtn.textContent = "Update Student";
        cancelBtn.classList.remove("hidden");

        window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (error) {
        showMessage(error.message, "error-message");
    }
}

async function deleteStudent(id) {
    const confirmed = confirm(`Delete student #${id}? This action cannot be undone.`);
    if (!confirmed) return;

    try {
        const response = await fetch(`${API_URL}${id}/`, {
            method: "DELETE"
        });

        if (!response.ok) {
            const result = await response.json().catch(() => ({}));
            throw new Error(result.detail || "Delete failed.");
        }

        showMessage("Student deleted successfully.", "success");
        await loadStudents();
    } catch (error) {
        showMessage(error.message, "error-message");
    }
}

function resetForm() {
    editingId = null;
    form.reset();
    clearErrors();
    formTitle.textContent = "Add Student";
    submitBtn.textContent = "Add Student";
    cancelBtn.classList.add("hidden");
}

function showServerErrors(errors) {
    clearErrors();

    const fields = ["name", "email", "phone", "department", "year", "cgpa"];
    let found = false;

    fields.forEach(field => {
        if (errors[field]) {
            const message = Array.isArray(errors[field])
                ? errors[field][0]
                : errors[field];
            setError(field, message);
            found = true;
        }
    });

    if (errors.detail) {
        showMessage(errors.detail, "error-message");
    } else if (!found) {
        showMessage("Please check the submitted data.", "error-message");
    }
}

function setError(field, message) {
    const element = document.getElementById(`${field}Error`);
    if (element) element.textContent = message;
}

function clearErrors() {
    document.querySelectorAll(".error").forEach(el => el.textContent = "");
}

function showMessage(text, type) {
    messageBox.textContent = text;
    messageBox.className = `message ${type}`;
    setTimeout(() => {
        messageBox.className = "message hidden";
    }, 4000);
}

function setApiStatus(text) {
    document.getElementById("apiStatus").textContent = text;
}

function yearLabel(year) {
    return {
        1: "1st Year",
        2: "2nd Year",
        3: "3rd Year",
        4: "4th Year"
    }[year] || year;
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

window.editStudent = editStudent;
window.deleteStudent = deleteStudent;
