from django.shortcuts import render
from rest_framework import generics
from rest_framework.response import Response
from rest_framework import status

from .models import Student
from .serializers import StudentSerializer


def home(request):
    return render(request, "students/index.html")


class StudentListCreateView(generics.ListCreateAPIView):
    serializer_class = StudentSerializer

    def get_queryset(self):
        queryset = Student.objects.all()
        search = self.request.query_params.get("search", "").strip()
        department = self.request.query_params.get("department", "").strip()

        if search:
            queryset = queryset.filter(
                name__icontains=search
            ) | queryset.filter(
                email__icontains=search
            ) | queryset.filter(
                phone__icontains=search
            )

        if department:
            queryset = queryset.filter(department=department)

        return queryset.distinct()


class StudentDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
