from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models


phone_validator = RegexValidator(
    regex=r"^\d{10}$",
    message="Phone number must contain exactly 10 digits.",
)


class Student(models.Model):
    DEPARTMENT_CHOICES = [
        ("Computer Science", "Computer Science"),
        ("Information Technology", "Information Technology"),
        ("Electronics", "Electronics"),
        ("Electrical", "Electrical"),
        ("Mechanical", "Mechanical"),
        ("Civil", "Civil"),
        ("Other", "Other"),
    ]

    YEAR_CHOICES = [
        (1, "1st Year"),
        (2, "2nd Year"),
        (3, "3rd Year"),
        (4, "4th Year"),
    ]

    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=254, unique=True)
    phone = models.CharField(max_length=10, validators=[phone_validator])
    department = models.CharField(max_length=50, choices=DEPARTMENT_CHOICES)
    year = models.PositiveSmallIntegerField(
        choices=YEAR_CHOICES,
        validators=[MinValueValidator(1), MaxValueValidator(4)],
    )
    cgpa = models.DecimalField(
        max_digits=4,
        decimal_places=2,
        validators=[MinValueValidator(0), MaxValueValidator(10)],
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return f"{self.name} ({self.email})"
