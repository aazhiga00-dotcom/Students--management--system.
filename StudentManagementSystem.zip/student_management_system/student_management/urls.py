from django.contrib import admin
from django.urls import include, path
from students.views import home

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/", include("students.urls")),
    path("", home, name="home"),
]
